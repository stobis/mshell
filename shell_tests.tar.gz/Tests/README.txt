1. Przed rozpoczęciem testów w rozpakowanym katalogu Tests uruchom 
	./prepare.sh
2. Po zakończeniu testów w Tests uruchom
	./clean.sh
3. Do uruchomienia wszystkich testów służy run_all.sh. Przykładowe wywołanie
	./run_all.sh ~/shell/mshell 
Nazwa katalogu w którym są wykonywane testy jest zdefiniowana w pliku "setup".
